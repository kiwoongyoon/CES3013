#include "animal.h"
#include <stdio.h>
int main(){
    printf("This is main.c \n");
    func1();
    func2();
    func3();
    return 0;
}
