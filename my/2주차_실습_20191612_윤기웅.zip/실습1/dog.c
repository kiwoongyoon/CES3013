#include "animal.h"
#include <stdio.h>

void func3(){
    printf("This is a dog\n");
}
