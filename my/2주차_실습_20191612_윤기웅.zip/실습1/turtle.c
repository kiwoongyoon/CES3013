#include "animal.h"
#include <stdio.h>

void func1(){
    printf("This is a turtle\n");
}
