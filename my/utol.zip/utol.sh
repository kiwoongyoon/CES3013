#!/bin/bash

echo "Working directory"
read dirname

# Check if directory input exist
if [ -n "$dirname" ]
then
	cd "$dirname"
    # Check if change directory was successful
	if [ $? != 0 ]
	then
		echo "Error: cant change to directory, verify permissions"
		exit 0
	fi
fi
# Loop through each dir in directory
for dir in *
do
    # Verify if it is a file
	if [ -f "$dir" ]
	then
        # Change file names from upper to lower case and vice versa
		mv "$dir" `echo "$dir" | tr 'A-Za-z' 'a-zA-Z'`	
	fi
done
