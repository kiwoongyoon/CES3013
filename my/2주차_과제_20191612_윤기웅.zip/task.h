void count_nums() ; 
void print_cnts() ;